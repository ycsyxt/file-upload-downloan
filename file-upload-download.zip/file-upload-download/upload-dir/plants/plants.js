;(function(global){
	var plants = new Plants();
	function Plants(){
		this.renderArr=[];//渲染数组
		this.renderArr2=[];//渲染数组
		this.renderArr3=[];//每一次重绘后都要清除这个数组
		
		this.urlObj={}//图片路径对象
		this.imgObj={};//图片对象
		this.count=14;//图片数量
		this.zombiesRunCount=22;//僵尸走动的图片数量
		this.wandousRunCount=13;//豌豆苗动画的图片数量
		this.zombiesDeadCount=10;//僵尸死亡图片数量
		this.sunRunCount=22;//太阳转动图片数量
		this.zombiesEatCount=21;//僵尸吃的图片数量
		this.sunPlantRunCount=18;//太阳花的图片数量
		
		this.plants=[];//植物集合
		this.zombies=[];//僵尸集合
		this.wandous=[];
		this.suns = [];//阳光
		
		this.bgRectArr=[];//田的背景方块
		this.cardRectArr=[];//卡片的背景方块
		this.cardArr=[];//卡片数组
			
		this.sunTotalCount=1000;//阳光默认50分
	
		this.sucCount=300;//300分结束游戏，没一个僵尸10分，打死30个僵尸获得胜利
		this.curCount=0;
	}
	//组装图片路径
	Plants.prototype.loadUrl=function(){
		//组装图片路径
		for(var i=this.count;i>=1;i--){
			this.urlObj[i]="images/"+i+".png";
		}
		//组装僵尸走动图片路径
		for(var i=1;i<=this.zombiesRunCount;i++){
			this.urlObj[this.count+i]="images/zombiesRun/("+i+").png";
		}
		//组装豌豆图片路径
		for(var i=1;i<=this.wandousRunCount;i++){
			this.urlObj[this.count+this.zombiesRunCount+i]="images/wandou/("+i+").png";
		}
		
		//组装僵尸死亡图片路径
		for(var i=1;i<=this.zombiesDeadCount;i++){
			this.urlObj[this.count+this.zombiesRunCount+this.wandousRunCount+i]="images/zombiesDead/("+i+").png";
		}
		//组装太阳转动图片路径
		for(var i=1;i<=this.sunRunCount;i++){
			this.urlObj[this.count+this.zombiesRunCount+this.wandousRunCount+this.zombiesDeadCount+i]="images/sun/("+i+").png";
		}
		
		//组装僵尸吃的图片路径
		for(var i=1;i<=this.zombiesEatCount;i++){
			this.urlObj[this.count+this.zombiesRunCount+this.wandousRunCount+this.zombiesDeadCount+this.sunRunCount+i]="images/zombiesEat/("+i+").png";
		}
		
		//组装僵尸吃的图片路径
		for(var i=1;i<=this.sunPlantRunCount;i++){
			this.urlObj[this.count+this.zombiesRunCount+this.wandousRunCount+this.zombiesDeadCount+this.sunRunCount+this.zombiesEatCount+i]="images/sunPlant/("+i+").png";
		}
		
		
	}
	//加载图片
	Plants.prototype.loadImg=function(fn){
		var that=this;
		var keys = Object.keys(this.urlObj);
		var url,key;
		var n=0;
		for(var i=0;i<keys.length;i++)
		{
			key=keys[i];
			url =  this.urlObj[keys[i]];
			var img=new Image();
			img.src=url;
			(function(k,obj){
				obj.onload=function(){
				that.imgObj[k]=obj;
				n++;
				
				if(n===keys.length){
					fn();
				}
			}
			})(key,img)
		}
	}
	
	//组装音乐对象
	Plants.prototype.initMusic=function(musicObj){
		var keys = Object.keys(musicObj);
		var key;
		for(var i=0;i<keys.length;i++)
		{
			key=keys[i];
			this[key]=musicObj[key];
		}
	}
	//初始化
	Plants.prototype.init=function(el,musicObj){
		if(!el) return ;
		this.el=el;
		this.loadUrl();
		this.initMusic(musicObj);
		
		var canvas = document.createElement('canvas');//创建画布
		canvas.style.cssText="background:white;";
		var W = canvas.width = 1000; //设置宽度
		var H = canvas.height = 600;//设置高度
		
		el.appendChild(canvas);//添加到指定的dom对象中
		this.ctx = canvas.getContext('2d');
		this.canvas=canvas;
		this.w=W;
		this.h=H;
		
		var canvas2 = document.createElement('canvas');//创建画布
		canvas2.style.cssText="position:absolute;left:0px;";//设置样式
		canvas2.width = W; //设置宽度
		canvas2.height = H;//设置高度
		el.appendChild(canvas2);//添加到指定的dom对象中
		this.ctx2 = canvas2.getContext('2d');
		this.canvas2=canvas2;
		
		//加载图片，并回调绘制出图片
		this.loadImg(this.draw.bind(this));
		//给canvas2画布添加鼠标移动事件（因为画布2在上面）
		canvas2.addEventListener('mousemove',this.mouseMove.bind(this));
		
		//给canvas2画布添加鼠标点击事件（因为画布2在上面）
		canvas2.addEventListener('click',this.mouseClick.bind(this));
		
		//给canvas2画布添加鼠标右键事件（因为画布2在上面）
		canvas2.addEventListener('contextmenu',this.contextMenu.bind(this));
	}
	//右键事件
	Plants.prototype.contextMenu=function(e){
		var e = e||window.event;
			//取消右键默认事件
		e.preventDefault && e.preventDefault();
		if(this.gameOver) return ;//目前设定的是结束后，要刷新页面才可以开始
		if(!this.startImage) return; //防止没加载完成报错
		if(!this.gameAlive)return;
				console.log('oncontextmenu');
		//正在创建的植物删除
		this.delPlant(this.currPlant,1);
		this.currPlant=null;
		//循环田背景数组
		for(var i=0;i<this.bgRectArr.length;i++){
			var item=this.bgRectArr[i];
			item.fillStyle="rgba(0,250,154, 0)";
		}
	}
	//鼠标移动事件
	Plants.prototype.mouseMove=function(e){
		var that=this;
		if(that.gameOver) return ;//目前设定的是结束后，要刷新页面才可以开始
		if(!this.startImage) return; //防止没加载完成报错
		var pos = _.getOffset(e);//获取鼠标位置
		var isCatch = this.startImage.isPoint(pos);//鼠标捕捉
		
		if(!isCatch  && this.gameAlive){
			isCatch = this.createZombiesImage.isPoint(pos);//鼠标捕捉
		}
		
		if(!isCatch){
			if(this.gameAlive && !this.currPlant) {//游戏开始，并且没有正在创建的植物的时候可以执行
				//循环卡片背景数组
				for(var i=0;i<this.cardRectArr.length;i++){
					var item=this.cardRectArr[i];
					if(item.isPoint(pos) && item.alive){//鼠标捕捉
						isCatch=true;
						break;
					}
				}
			}
		}
		if(!isCatch){
			//循环太阳数组
			for(var i=0;i<this.suns.length;i++){
				var item=this.suns[i];
				if(item.isPoint(pos)){//鼠标捕捉
					isCatch=true;
					break;
				}
			}
		}
		
		var plant = this.currPlant;
		if(!isCatch){
			if(plant){//创建植物的时候，才出现填入背景框
				//循环田背景数组
				for(var i=0;i<this.bgRectArr.length;i++){
					var item=this.bgRectArr[i];
					if(item.isPoint(pos) && !item.plant){//鼠标捕捉，并且当前没有植物
						isCatch=true;
						item.fillStyle="rgba(0,250,154, 0.5)";
					}else{
						item.fillStyle="rgba(0,250,154, 0)";
					}
				}
			}
		}
		
		if(isCatch){
			this.el.style.cursor = 'pointer';//改为手状形态
		}else{
			this.el.style.cursor = '';
		}
		//表示当前正在创建植物
		if(plant){
			plant.dx=pos.x;
			plant.dy=pos.y;
		}
		
		this.render2();
	}
	//鼠标点击事件
	Plants.prototype.mouseClick=function(e){
		if(this.gameOver) return ;//目前设定的是结束后，要刷新页面才可以开始
		var that=this;
		var pos = _.getOffset(e);//获取鼠标位置
		var isCatch = that.startImage.isPoint(pos);//鼠标捕捉
		if(isCatch){
			that.start();
		}
		if(!isCatch && this.gameAlive){
			isCatch = this.createZombiesImage.isPoint(pos);//鼠标捕捉
			if(isCatch){
				that.createZombie();
			}
		}
		if(!isCatch){
			if(this.gameAlive && !this.currPlant) {//游戏开始，并且没有正在创建的植物的时候可以执行
				//循环卡片数组
				for(var i=0;i<this.cardRectArr.length;i++){
					var item=this.cardRectArr[i];
					if(item.isPoint(pos) && item.alive){//鼠标捕捉
						isCatch=true;
						//生成一个新的豌豆苗，跟随鼠标移动
						this.createPlant(pos,item);//创建植物
						break;
					}
				}
			}
		}
		
		if(!isCatch){
			//循环太阳数组
			for(var i=0;i<this.suns.length;i++){
				var item=this.suns[i];
				if(item.isPoint(pos)){//鼠标捕捉
					item.click && item.click();
					break;
				}
			}
		}
		if(!isCatch){
			var plant = this.currPlant;
			if(plant){//正在创建植物
				//循环田背景数组
				for(var i=0;i<this.bgRectArr.length;i++){
					var item=this.bgRectArr[i];
					if(item.plant) continue;//如果当前有植物，则跳过
					if(item.isPoint(pos)){//鼠标捕捉
						isCatch=true;
						plant.dx=item.x+10;
						plant.dy=item.y+20;
						plant.index=item.index;//给plant设置行数
						plant.alive(item);//植物生效
						
						item.plant=true;//表示有植物
						item.fillStyle="rgba(0,250,154, 0)";
						
						this.currPlant=null;
						break;
					}
				}
			}
		
		}	
	}
	
	//渲染图形
	Plants.prototype.render=function(){
		var context=this.ctx;
		this.clearCanvas();	
		_.each(this.renderArr,function(item){
			item && item.render(context);
		});
	}
	
	//渲染图形2
	Plants.prototype.render2=function(){
		var context2=this.ctx2;
		this.clearCanvas2();	
		_.each(this.renderArr2,function(item){
			item && item.render(context2);
		});
		
		_.each(this.renderArr3,function(item){
			item && item.render(context2);
		});
	}
	 
	//清洗画布
	Plants.prototype.clearCanvas=function() {
		this.ctx.clearRect(0,0,parseInt(this.w),parseInt(this.h));
    }
    //清洗画布
	Plants.prototype.clearCanvas2=function() {
		this.ctx2.clearRect(0,0,parseInt(this.w),parseInt(this.h));
    }
    
	//绘制入口
	Plants.prototype.draw=function(){
		this.drawBG();
		this.drawCard();
		this.render();//执行渲染
	}
	//绘制背景
	Plants.prototype.drawBG=function(){
		var image,img,sx=150,sy=0,sWidth=900,sHeight=600,dx=0,dy=0,dWidth=900,dHeight=600;
		//背景
		image = this.imgObj[1];
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.renderArr.push(img);
	}
	//绘制游戏上方的相关图片（卡片等）
	Plants.prototype.drawCard=function(){
		var image,img,sx=0,sy=0,sWidth=446,sHeight=87,dx=0,dy=0,dWidth=446,dHeight=80;
		//方形卡片盘
		image = this.imgObj[2];
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.renderArr.push(img);
		
		sWidth=128,sHeight=31,dx=450,dy=0,dWidth=128,dHeight=40;
		//积分
		image = this.imgObj[12];
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.renderArr.push(img);
		
		sWidth=50,sHeight=70,dx=76,dy=5,dWidth=50,dHeight=68;
		//方形卡片 太阳花
		image = this.imgObj[3];
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		img.sunCost=50;//生产一个苗需要50阳光
		img.type='sun';//植物类型
		this.renderArr.push(img);
		this.cardArr.push(img);
		
		sWidth=50,sHeight=70,dx=130,dy=4,dWidth=50,dHeight=70;
		//方形卡片 豌豆
		image = this.imgObj[4];
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		img.sunCost=100;//生产一个苗需要100阳光
		img.type='wandou';//植物类型
		this.renderArr.push(img);
		this.cardArr.push(img);

		
		sWidth=97,sHeight=33,dx=780,dy=8,dWidth=97,dHeight=33;
		//开始按钮图片
		image = this.imgObj[5];
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.startImage=img;
		this.renderArr.push(img);
		
		sWidth=97,sHeight=33,dx=650,dy=8,dWidth=97,dHeight=33;
		//创建僵尸图片
		image = this.imgObj[8];
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.createZombiesImage=img;
		this.renderArr.push(img);
	}
	
	//创建植物田背景方形
	Plants.prototype.createBGRect=function(){
		var x=0,y=0,rect;
		for(var i=1;i<=5;i++){//5行
			y = 75+(i-1)*100;
			for(var j=1;j<=9;j++){//9列
				x = 105+(j-1)*80;
				rect = new _.Rect({
					x:x,
					y:y,
					width:80,
					height:100,
					fill:true,
					//fillStyle:_.getRandomColor()
					fillStyle:'rgba(0,250,154, 0)'
				 })
				 rect.index=i;//标记行数
				 this.renderArr2.push(rect);
				 this.bgRectArr.push(rect);
			}
		}
	}
	
	
	//创建僵尸
	Plants.prototype.createZombie=function(){
		var image,zomble,sx=0,sy=0,sWidth=75,sHeight=119,dx=900-75,dy=270,dWidth=75,dHeight=119;
		
		var index = _.getRandom(1,6);//随机获取1\2\3\4\5 行数
		if(index==1){
			dy=60;
		}else if(index==2){
			dy=160;
		}else if(index==3){
			dy=260;
		}else if(index==4){
			dy=355;
		}else if(index==5){
			dy=460;
		}
		
		//绘制时的图片下标
		var startKey=this.count+1;
		//方形卡片盘
		image = this.imgObj[startKey];
		zomble = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		zomble.imageKey=startKey;//执行动画更新的下标
		zomble.key=startKey;//原始下标
		zomble.blood=10;//默认10点血量
		zomble.index=index;//设定僵尸的行数
		zomble.state='run';
		this.renderArr2.push(zomble);
		this.zombies.push(zomble);
		
		zomble.run=run.bind(this);
		
		zomble.run();
		
		function run(){
			zomble.timmer = setInterval(animate.bind(this,zomble),100);
		}
		function animate(z){
			var that=this;
			z.imageKey ++;
			//一个循环了，重新回到初始位置
			if(z.imageKey>=(that.zombiesRunCount+z.key)){
				z.imageKey=z.key;
			}
			z.image = that.imgObj[z.imageKey];
			z.dx-=2;
			//判断有没有接触到植物，如果有开始吃植物 
			that.eat(zomble)
			
			if(z.dx<=100){
				console.log('结束了');
				that.end();
			}	
		}
	}
	//游戏结束
	Plants.prototype.end=function(type){
		this.bgMusic.pause();
		if(type=='suc'){
			this.winMusic.play();
		}else{
			this.lostMusic.play();
		}
		
		this.gameAlive=false;
		this.gameOver=true;
		var that=this;
		//停止产生阳光动画
		clearInterval(that.timmerSun);
		//停止生产僵尸动画
		clearInterval(that.timmerZoms);
		//停止产生阳光动画
		_.each(that.suns,function(item){
			clearInterval(item.timmer);
		})
		//停止僵尸动画
		_.each(that.zombies,function(item){
			clearInterval(item.timmer);
		})
		//停止树苗动画
		_.each(that.plants,function(item){
			if(item){
				//停止植物自身的动画
				clearInterval(item.timmerSelf);
				//停止植物发射子弹的动画
				clearInterval(item.timmer);
			} 
		})
		
		//停止游戏动画
		clearInterval(that.timmer);
		
		that.endShow(type);
	}
	//僵尸吃
	Plants.prototype.eat=function(zomble){
		//先判断当前僵尸有没有到达吃的位置，有的话就开始吃，关闭掉之前的僵尸动画，开始吃的动画
		var plants=this.plants;
		var plant;//被捕获的植物
		for(var i=0;i<plants.length;i++){
			var item=plants[i];
			if(item.index==zomble.index){
				if(item.dx+item.dWidth-20>=zomble.dx){//判断为吃
					plant=item;
					break;
				}
			}
			
		}
		if(plant){
			clearInterval(zomble.timmer);//清除移动动画
			zomble.imageKey=zomble.key=this.count+this.zombiesRunCount+this.wandousRunCount+this.zombiesDeadCount+this.sunRunCount+1;//设定key
			zomble.state='eat';
			zomble.timmer = setInterval(animate.bind(this,zomble,plant),100);
		}
		
		function animate(z,p){
			this.eatMusic.play();
			var that=this;
			z.imageKey ++;
			//一个循环了，重新回到初始位置
			if(z.imageKey>=(that.zombiesEatCount+z.key)){
				z.imageKey=z.key;
			}
			z.image = that.imgObj[z.imageKey];
			
			p.blood--;//植物血量的处理
			if(p.blood<=0){
				//console.log('植物被吃了');
				clearInterval(z.timmer);
				//清除植物
				this.delPlant(p);
				zomble.state='run';
				zomble.imageKey=zomble.key=this.count+1;//设定key
				//继续移动
				z.run();
			}
		}
	}
	//删除掉植物
	Plants.prototype.delPlant=function(plant,type){
		if(!type){//还没有创建的植物不需要清除这两个任务
			//停止植物自身的动画
			clearInterval(plant.timmerSelf);
			//停止植物发射子弹的动画
			clearInterval(plant.timmer);
		}
		//渲染中删除
		this.clear(plant);
		//plants数组中删除
		this.clearAssign(this.plants,plant);
		//植物对应的背景处理
		if(plant.bgRect){
			plant.bgRect.alive=false;
			plant.bgRect.plant=false;
		}
		plant=null;
	}
	//创建植物的入口
	Plants.prototype.createPlant=function(pos,item){
		if(item.type=='sun'){
			this.createSunPlant(pos,item);
		}else if(item.type=='wandou'){
			this.createWandouPlant(pos,item);
		}
	}
	
	
	//创建太阳植物
	Plants.prototype.createSunPlant=function(pos,item){
		var image,plant,sx=0,sy=0,sWidth=63,sHeight=73,dx=110,dy=300,dWidth=63,dHeight=73;
		dx = pos.x,dy=pos.y;//设定初始位置为鼠标的位置
		//绘制时的图片下标
		var startKey=this.count+this.zombiesRunCount+this.wandousRunCount+this.zombiesDeadCount+this.sunRunCount+this.zombiesEatCount+1;
		//方形卡片盘
		image = this.imgObj[startKey];
		plant = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		plant.imageKey=startKey;//执行动画更新的下标
		plant.key=startKey;//原始下标
		plant.sunCost=item.sunCost;//阳光花费值
		plant.blood=50;//设定为50血量，实际是5秒吃完，因为100毫秒计算一次吃
		plant.id='SunPlant';
		this.renderArr2.push(plant);
		
		this.plants.push(plant);
		this.currPlant=plant;//标记正在创建的植物
		
		plant.alive=alive.bind(this);
		
		function alive(bgRect){
			//设置背景对象
			plant.bgRect=bgRect;
			//扣除阳光花费
			this.sunTotalCount-=plant.sunCost;
			//更新卡片是否可用情况
			this.updateCardUse();
			//更新阳光数值
			this.sunCountObj.text=this.sunTotalCount;
			//每6秒发射一个阳光
			plant.timmer = setInterval(shoot.bind(this),6000);
			this.plantMusic.play();//音乐
		}
		
		function shoot(){
			this.createSun(plant);
		}
		//植物本身的动画
		plant.timmerSelf = setInterval(animate.bind(this,plant),100);
		function animate(p){
			var that=this;
			p.imageKey ++;
			//一个循环了，重新回到初始位置
			if(p.imageKey>=(that.sunPlantRunCount+p.key)){
				p.imageKey=p.key;
			}
			p.image = that.imgObj[p.imageKey];
		}
	}
	
	//创建豌豆植物
	Plants.prototype.createWandouPlant=function(pos,item){
		var image,plant,sx=0,sy=0,sWidth=63,sHeight=73,dx=110,dy=300,dWidth=63,dHeight=73;
		dx = pos.x,dy=pos.y;//设定初始位置为鼠标的位置
		//绘制时的图片下标
		var startKey=this.count+this.zombiesRunCount+1;
		//方形卡片盘
		image = this.imgObj[startKey];
		plant = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		plant.imageKey=startKey;//执行动画更新的下标
		plant.key=startKey;//原始下标
		plant.sunCost=item.sunCost;//阳光花费值
		plant.blood=50;//设定为50血量，实际是5秒吃完，因为100毫秒计算一次吃
		plant.id='WandouPlant';
		this.renderArr2.push(plant);
		
		this.plants.push(plant);
		this.currPlant=plant;//标记正在创建的豌豆
		
		plant.alive=alive.bind(this);
		
		function alive(bgRect){
			//设置背景对象
			plant.bgRect=bgRect;
			//扣除阳光花费
			this.sunTotalCount-=plant.sunCost;
			//更新卡片是否可用情况
			this.updateCardUse();
			//更新阳光数值
			this.sunCountObj.text=this.sunTotalCount;
			//每两秒发射一个豌豆
			plant.timmer = setInterval(shoot.bind(this),2000);
			this.plantMusic.play();//音乐
		}
		
		function shoot(){
			this.createWandou(plant);
		}
		//豌豆苗本身的动画
		plant.timmerSelf = setInterval(animate.bind(this,plant),100);
		function animate(p){
			var that=this;
			p.imageKey ++;
			//一个循环了，重新回到初始位置
			if(p.imageKey>=(that.wandousRunCount+p.key)){
				p.imageKey=p.key;
			}
			p.image = that.imgObj[p.imageKey];
		}
	}
	
	//创建豌豆
	Plants.prototype.createWandou=function(plant){
		var image,img,sx=0,sy=0,sWidth=28,sHeight=28,dx=plant.dx+50,dy=plant.dy,dWidth=28,dHeight=28;
		//绘制时的图片下标
		var startKey=6;
		//方形卡片盘
		image = this.imgObj[startKey];
		var wandou= new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.renderArr2.push(wandou);
		
		wandou.index=plant.index;//给子弹设定行数标示
		
		this.shootMusic.play();//射击音乐
		wandou.timmer = setInterval(wandouMove.bind(this,wandou),100);

		function wandouMove(wandou){
			wandou.dx+=10;
			//判断击中僵尸
			var flag = this.hit(wandou);
			if(flag || wandou.dx>850){//击中目标 或者 超出边界
				clearInterval(wandou.timmer);
				if(flag){//击中目标
					//创建子弹击中的图片
					this.hitAnimate(wandou);
					this.hitMusic.play();//击中音乐
				}
				//清除这个子弹
				this.clear(wandou);
				wandou=null;
			}
		}
	}
	//击中
	Plants.prototype.hit=function(obj){
		var arr = this.zombies;//僵尸对象
		for(var i=0;i<arr.length;i++){
			var item = arr[i];
			if(item.dx<=obj.dx+obj.dWidth && obj.index==item.index ){//子弹的函数标示与僵尸的行数标示也要相等
				item.blood--;
				if(item.blood==0){//消灭这个僵尸
					clearInterval(item.timmer);
					if(item.state=='run'){
						item.imageKey=item.key=item.key+this.zombiesRunCount+this.wandousRunCount;//设置死亡图片下标
					}else if(item.state=='eat'){
						item.imageKey=item.key=item.key-this.sunRunCount-this.zombiesDeadCount;//设置死亡图片下标
					}
					
					item.state='dead';
					this.addCount();//增加积分
					this.dead(item);//死亡动画
					arr.splice(i,1);
				}
				return true;
			}
		}
	}
	//积分
	Plants.prototype.addCount=function(item){
		this.curCount+=10;
		this.countObj.text=this.curCount;
		if(this.curCount >= this.sucCount){
			this.end('suc');
		}
	}
	
	//死亡
	Plants.prototype.dead=function(item){
		this.deadMusic.play();
		item.timmer = setInterval(animate.bind(this,item),200);
		function animate(z){
			var that=this;
			z.imageKey ++;
			z.image = that.imgObj[z.imageKey];
			//设置相关参数，让图片完全展示
			z.dWidth=165;
			z.sWidth=165;
			z.dx-=5;
			z.dy+=10;
			//死彻底了
			
			if(z.imageKey>=that.zombiesDeadCount+z.key){
				//清除这个僵尸
				this.clear(z);
				clearInterval(z.timmer);
				z=null;
			}
		}
	}
	//清除对象
	Plants.prototype.hitAnimate=function(w){
		var image,hit,sx=0,sy=0,sWidth=51,sHeight=45,dx=w.dx,dy=w.dy,dWidth=51,dHeight=45;
		//击中
		image = this.imgObj[7];
		hit = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.renderArr3.push(hit);
	}
	
	//清除对象
	Plants.prototype.clear=function(obj){
		var arr = this.renderArr2;
		for(var i=0;i<arr.length;i++){
			var item = arr[i];
			if(item==obj){
				arr.splice(i,1);
				break;
			}
		}
	}
	//清楚指定数组的对象
	Plants.prototype.clearAssign=function(arr,obj){
		for(var i=0;i<arr.length;i++){
			var item = arr[i];
			if(item==obj){
				arr.splice(i,1);
				break;
			}
		}
	}
	
	//创建阳光
	Plants.prototype.createSun=function(plant){
		var image,sun,sx=0,sy=0,sWidth=77,sHeight=74,dx=0,dy=70,dWidth=45,dHeight=44;
		
		if(plant){//这种是植物创建的太阳
			dx = plant.dx;
			dy = plant.dy;
		}else{
			dx = _.getRandom(200,800);//x方形随机200-800
		}
		
		//绘制时的图片下标
		var startKey=this.count+this.zombiesRunCount+this.wandousRunCount+this.zombiesDeadCount+1;
		//方形卡片盘
		image = this.imgObj[startKey];
		sun = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		sun.imageKey=startKey;//执行动画更新的下标
		sun.key=startKey;//原始下标
		sun.value=20;//收集一个20分
		sun.blood=100;//默认10点血量（10秒消失，因为我给太阳设置的是100毫秒执行一次，所以这个blood设置为100，每次-1 ，10秒就刚好100）
		sun.floor=400;//到底的位置
		this.renderArr2.push(sun);
		
		this.suns.push(sun);
		
		sun.timmer = setInterval(animate.bind(this,sun),100);
		function animate(z){
			var that=this;
			z.imageKey ++;
			//一个循环了，重新回到初始位置
			if(z.imageKey>=(that.sunRunCount+z.key)){
				z.imageKey=z.key;
			}
			z.image = that.imgObj[z.imageKey];
			z.dy+=2;
			if(z.dy>=z.floor){
				//console.log('太阳到位置了');
				clearInterval(z.timmer);
				//开启定时任务，多少秒以后消失
				sun.timmer = setInterval(time.bind(this,sun),100);
			}
		}
		
		//太阳计时
		function time(z){
			var that=this;
			z.imageKey ++;
			//一个循环了，重新回到初始位置
			if(z.imageKey>=(that.sunRunCount+z.key)){
				z.imageKey=z.key;
			}
			z.image = that.imgObj[z.imageKey];
			//计算消失时间
			z.blood--;
			if(z.blood<=0){
				clearInterval(z.timmer);
				//console.log('太阳到时间了');
				fade.call(this,z);//执行消失
			}
		}
		
		//太阳消失
		function fade(z){
			this.clear(z);
			//console.log('太阳消失了');
			this.clearAssign(this.suns,z);//清楚指定对象
			z=null;
		}
		//太阳被点击
		function sunClick(z){
			//console.log('太阳被点击了')
			clearInterval(z.timmer);//清楚之前的定时器
			
			this.pointsMusic.play();
			
			var cx=cy=20;//收集点的X\Y坐标
			var angle = Math.atan2((z.dy-cy), (z.dx-cx))  //弧度 
			
			//计算出X\Y每一帧移动的距离
			var mx = my=0;
			mx = Math.cos(angle)*20;
			my = Math.sin(angle)*20;
			z.mx=mx,z.my=my;
			//开启移动定时器
			z.timmer = setInterval(sunCollect.bind(this,z),100);
		}
		//收集太阳动画
		function sunCollect(z){
			var that=this;
			z.imageKey ++;
			//一个循环了，重新回到初始位置
			if(z.imageKey>=(that.sunRunCount+z.key)){
				z.imageKey=z.key;
			}
			z.image = that.imgObj[z.imageKey];
			z.dx-=z.mx;
			z.dy-=z.my;
			if(z.dy<=20||z.dx<=20){
				//console.log('太阳收集完成');
				clearInterval(z.timmer);
				
				this.moneyfallsMusic.play();
				
				fade.call(this,z);//执行消失
				//计数累加
				that.sunTotalCount+=z.value;
				
				//更新卡片是否可用情况
				that.updateCardUse();
				//更新阳光数值
				that.sunCountObj.text=that.sunTotalCount;
			}
		}
		
		sun.click=sunClick.bind(this,sun);//给这个sun对象绑定点击函数
	}
	
	//创建阳光分
	Plants.prototype.createSunText=function(){
		x=40,y=74,content=this.sunTotalCount;
		var	text = new _.Text({
			x:x,
			y:y,
			text:content,
			font:'20px ans-serif',
			textAlign:'center',
			fill:true,
			fillStyle:'green'
		});	
		this.renderArr2.push(text);	
		this.sunCountObj=text;
	}
	
	//创建积分
	Plants.prototype.createCountText=function(){
		x=530,y=34,content=this.curCount;
		var	text = new _.Text({
			x:x,
			y:y,
			text:content,
			font:'30px ans-serif',
			textAlign:'center',
			fill:true,
			fillStyle:'pink'
		});	
		this.renderArr2.push(text);	
		this.countObj=text;
	}
	
	//创建卡片背景方形
	Plants.prototype.createCardBGRect=function(){
		var x=0,y=0,rect,fillStyle,alive;
		for(var i=0;i<this.cardArr.length;i++){
			var item=this.cardArr[i];
			fillStyle = this.sunTotalCount>=item.sunCost? 'rgba(192,192,192,0)':'rgba(192,192,192,0.5)';
			alive = this.sunTotalCount>=item.sunCost? true:false;
			rect = new _.Rect({
				x:item.dx,
				y:item.dy,
				width:item.dWidth,
				height:item.dHeight,
				fill:true,
				fillStyle:fillStyle
			 })
			 rect.sunCost=item.sunCost;//设定需要花费的阳光数值
			 rect.alive=alive;
			 rect.type=item.type;
			 this.renderArr2.push(rect);
			 this.cardRectArr.push(rect);
		}
		
	}
	
	//创建一个僵尸
	Plants.prototype.doCreateZombie=function(){
		this.createZombie();//创建一个僵尸
	}
	//根据阳光的收集情况，处理卡片是否可用
	Plants.prototype.updateCardUse=function(){
		//循环卡片背景数组
		var fillStyle;
		for(var i=0;i<this.cardRectArr.length;i++){
			var item=this.cardRectArr[i];
			if(this.sunTotalCount>=item.sunCost){
				item.alive=true;//卡片可用
				item.fillStyle='rgba(192,192,192,0)';
			}else{
				item.alive=false;//卡片不可用
				item.fillStyle='rgba(192,192,192,0.5)';
			}
		}
	}
	//展示开始图片
	Plants.prototype.startShow=function(){
		var image,img,sx=0,sy=0,sWidth=225,sHeight=108,dx=this.w/2-110,dy=this.h/2-100,dWidth=225,dHeight=108;
		image = this.imgObj[10];
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.renderArr2.push(img);
		
		var that=this;
		setTimeout(function(){
			that.clear(img);
		},2000);
	}
	//展示结束的图片（胜利或者失败）
	Plants.prototype.endShow=function(type){
		var image,img,sx=0,sy=0,sWidth=225,sHeight=108,dx=this.w/2-110,dy=this.h/2-100,dWidth=225,dHeight=108;
		if(type=='suc'){
			image = this.imgObj[14];
		}else{
			image = this.imgObj[13];
		}
		
		img = new _.ImageDraw({image:image,sx:sx,sy:sy,sWidth:sWidth,sHeight:sHeight, dx:dx, dy:dy ,dWidth:dWidth,dHeight:dHeight});
		this.renderArr2.push(img);
		
		this.render2();
	}
	
	
	//开始
	Plants.prototype.start=function(){
		if(this.timmer) return ;
		if(this.gameOver) return ;
		this.startShow();//展示开始图片
		this.bgMusic.play();//开启背景音乐
		this.createSunText();//创建阳光计分显示
		this.createCountText();//创建积分显示
		this.createBGRect();//创建田的背景方形
		this.createCardBGRect();//创建卡牌的背景方形
		//100毫秒执行一次（这个是专门刷新动画的定时器）
		this.timmer = setInterval(this.startRun.bind(this),100);//开启总任务
		this.timmerSun = setInterval(this.createSun.bind(this),5000);//定时创建太阳光
		this.timmerZoms = setInterval(this.createZoms.bind(this),10000);//定时创建僵尸
		
		this.gameAlive=true;
	}
	//定时创建5个僵尸
	Plants.prototype.createZoms=function(){
		var count = _.getRandom(1,6);//随机数量的僵尸
		for(var i=0;i<count;i++){
			this.createZombie();//创建一个僵尸
		}
	}
	//执行
	Plants.prototype.startRun=function(){
		this.render2();
		
		this.renderArr3.length=0;
	}
	
	global.plants=plants;	
})(window);