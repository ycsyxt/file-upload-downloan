<template>
  <div v-loading="loading" :style="'height:'+ height">
    <iframe :src="src" frameborder="no" style="width: 100%;height: 100%" scrolling="hidden" />
  </div>
</template>
<script>
  export default {
    data() {
      return {
        src: "http://localhost:8080/plants/plants.html",
        height: document.documentElement.clientHeight + "px;",
        loading: true
      };
    },
    mounted: function() {
      setTimeout(() => {
        this.loading = false;
      }, 230);
      const that = this;
      window.onresize = function temp() {
        that.height = document.documentElement.clientHeight + "px;";
      };
    }
  };
</script>
