<template>
  <el-container>
    <el-aside width="200px">
      <el-menu class="el-menu-vertical-demo" router :default-active="$route.path">
        <el-submenu index="1">
          <template slot="title">
            <i class="el-icon-folder-opened"></i>
            <span slot="title">服务器资源</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="/images">图库</el-menu-item>
            <el-menu-item index="/perfect">html特效</el-menu-item>
            <el-menu-item index="/plants">植物大战僵尸</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
      </el-menu>
    </el-aside>
    <el-main>
      <router-view />
    </el-main>
  </el-container>
</template>

<script>
  export default {
    data() {
      return {
        isCollapse: true
      };
    },
    methods: {
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      }
    }
  }
</script>

<style>
  .el-menu-vertical-demo:not(.el-menu--collapse) {
    position: absolute;
    top: 0;
    bottom: 0;
  }
</style>