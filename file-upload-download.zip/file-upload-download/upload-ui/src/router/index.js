import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

import Layout from '@/layout'

export const routes = [
  {
    path: '/',
    component: Layout,
    redirect: "images",
    children: [
      {
        path: '/images',
        component: (resolve) => require(['@/views/images'], resolve)
      },
      {
        path: '/plants',
        component: (resolve) => require(['@/views/plants'], resolve)
      },
      {
        path: '/perfect',
        component: (resolve) => require(['@/views/perfect'], resolve)
      }
    ]
  }
]

export default new Router({
  mode: 'history', // 去掉url中的#
  scrollBehavior: () => ({ y: 0 }),
  routes: routes
})
