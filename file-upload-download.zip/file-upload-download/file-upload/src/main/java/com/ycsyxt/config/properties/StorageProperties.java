package com.ycsyxt.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author yuxt
 * @date 2021/4/24
 */
@ConfigurationProperties("storage")
public class StorageProperties {

    /**
     * 文件上传路径
     */
    private String location = "upload-dir";

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}